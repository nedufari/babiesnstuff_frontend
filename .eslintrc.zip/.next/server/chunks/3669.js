exports.id=3669,exports.ids=[3669],exports.modules={12973:(e,t,r)=>{Promise.resolve().then(r.bind(r,64653)),Promise.resolve().then(r.bind(r,68072))},8609:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});var i=r(10326),n=r(6420),a=r(25609);r(17577);var o=r(46226);let s=({quantity:e,price:t,product:r})=>(0,i.jsxs)(n.Z,{sx:{width:"100%",display:"flex",paddingLeft:"1rem",paddingY:"1rem",borderBottom:"1px solid #DEDEDE"},children:[(0,i.jsxs)(n.Z,{sx:{flex:5,display:"flex",flexDirection:{xs:"column",md:"row"},gap:"2rem"},children:[r.productImages.length>1?i.jsx(n.Z,{sx:{width:"100px",height:"100px",borderRadius:"50%","& > img":{position:"static !important",borderRadius:"50%"}},children:i.jsx(o.default,{src:r.productImages[0],alt:r.name,fill:!0,sizes:"100%",style:{width:"100%",height:"100%"}})}):i.jsx(n.Z,{sx:{width:"100px",height:"100px",borderRadius:"50%","& > img":{position:"static !important",borderRadius:"50%"}},children:i.jsx(o.default,{src:"/assets/images/image-131.png",alt:"Product picture",height:100,width:100,loading:"lazy",style:{maxWidth:"100%",height:"auto"}})}),(0,i.jsxs)(n.Z,{children:[i.jsx(a.Z,{variant:"poster",color:"#000",fontWeight:"500",fontSize:"24px",lineHeight:"29.05px",children:r.name}),(0,i.jsxs)(a.Z,{variant:"poster",color:"#000",fontWeight:"400",fontSize:"20px",lineHeight:"24.2px",children:["Size: ",r.available_sizes?r.available_sizes[0]:null]})]})]}),i.jsx(a.Z,{variant:"poster",color:"#323232",fontWeight:"600",fontSize:"24px",lineHeight:"29.05px",sx:{flex:1},children:e}),(0,i.jsxs)(a.Z,{variant:"poster",color:"#323232",fontWeight:"500",fontSize:"24px",lineHeight:"29.05px",sx:{flex:1},children:["₦",t]})]})},59617:(e,t,r)=>{"use strict";r.d(t,{By:()=>n,N6:()=>i,gv:()=>a});let{useGetSingleOrderQuery:i,useConfirmOrderMutation:n,useGetAllOrdersQuery:a}=r(63955).g.injectEndpoints({endpoints:e=>({getSingleOrder:e.query({query:e=>({url:`/order/get-one-order/${e}`,method:"GET",validateStatus:(e,t)=>200===e.status&&!t.isError}),providesTags:(e,t,r)=>[{type:"orders",id:r}]}),confirmOrder:e.mutation({query:e=>{let{id:t,...r}=e;return{url:`order/confirm-order/${t}`,method:"POST",body:r}},invalidatesTags:[{type:"orders",id:"LIST"}]}),getAllOrders:e.query({query:()=>({url:"/order-mgt/get-all-orders",method:"GET",validateStatus:(e,t)=>200===e.status&&!t.isError}),providesTags:e=>e?[...e.map(({id:e})=>({type:"orders",id:e})),{type:"orders",id:"LIST"}]:[{type:"orders",id:"LIST"}],transformResponse:e=>e.payload.orders[0]})}),overrideExisting:!0})},55976:(e,t,r)=>{"use strict";r.d(t,{Z:()=>C});var i=r(91367),n=r(45353),a=r(17577),o=r(41135),s=r(8106),l=r(88634),d=r(19452),c=r(22553),p=r(91703),u=r(2791),h=r(71685),m=r(97898);function g(e){return(0,m.ZP)("MuiSkeleton",e)}(0,h.Z)("MuiSkeleton",["root","text","rectangular","rounded","circular","pulse","wave","withChildren","fitContent","heightAuto"]);var f=r(10326);let v=["animation","className","component","height","style","variant","width"],x=e=>e,y,b,S,w,Z=e=>{let{classes:t,variant:r,animation:i,hasChildren:n,width:a,height:o}=e;return(0,l.Z)({root:["root",r,i,n&&"withChildren",n&&!a&&"fitContent",n&&!o&&"heightAuto"]},g,t)},O=(0,s.F4)(y||(y=x`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`)),j=(0,s.F4)(b||(b=x`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`)),k=(0,p.ZP)("span",{name:"MuiSkeleton",slot:"Root",overridesResolver:(e,t)=>{let{ownerState:r}=e;return[t.root,t[r.variant],!1!==r.animation&&t[r.animation],r.hasChildren&&t.withChildren,r.hasChildren&&!r.width&&t.fitContent,r.hasChildren&&!r.height&&t.heightAuto]}})(({theme:e,ownerState:t})=>{let r=(0,d.Wy)(e.shape.borderRadius)||"px",i=(0,d.YL)(e.shape.borderRadius);return(0,n.Z)({display:"block",backgroundColor:e.vars?e.vars.palette.Skeleton.bg:(0,c.Fq)(e.palette.text.primary,"light"===e.palette.mode?.11:.13),height:"1.2em"},"text"===t.variant&&{marginTop:0,marginBottom:0,height:"auto",transformOrigin:"0 55%",transform:"scale(1, 0.60)",borderRadius:`${i}${r}/${Math.round(i/.6*10)/10}${r}`,"&:empty:before":{content:'"\\00a0"'}},"circular"===t.variant&&{borderRadius:"50%"},"rounded"===t.variant&&{borderRadius:(e.vars||e).shape.borderRadius},t.hasChildren&&{"& > *":{visibility:"hidden"}},t.hasChildren&&!t.width&&{maxWidth:"fit-content"},t.hasChildren&&!t.height&&{height:"auto"})},({ownerState:e})=>"pulse"===e.animation&&(0,s.iv)(S||(S=x`
      animation: ${0} 2s ease-in-out 0.5s infinite;
    `),O),({ownerState:e,theme:t})=>"wave"===e.animation&&(0,s.iv)(w||(w=x`
      position: relative;
      overflow: hidden;

      /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
      -webkit-mask-image: -webkit-radial-gradient(white, black);

      &::after {
        animation: ${0} 2s linear 0.5s infinite;
        background: linear-gradient(
          90deg,
          transparent,
          ${0},
          transparent
        );
        content: '';
        position: absolute;
        transform: translateX(-100%); /* Avoid flash during server-side hydration */
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
      }
    `),j,(t.vars||t).palette.action.hover)),C=a.forwardRef(function(e,t){let r=(0,u.i)({props:e,name:"MuiSkeleton"}),{animation:a="pulse",className:s,component:l="span",height:d,style:c,variant:p="text",width:h}=r,m=(0,i.Z)(r,v),g=(0,n.Z)({},r,{animation:a,component:l,variant:p,hasChildren:!!m.children}),x=Z(g);return(0,f.jsx)(k,(0,n.Z)({as:l,ref:t,className:(0,o.Z)(x.root,s),ownerState:g},m,{style:(0,n.Z)({width:h,height:d},c)}))})},94364:(e,t,r)=>{"use strict";r.d(t,{Z:()=>d});var i=r(17577),n={cm:!0,mm:!0,in:!0,px:!0,pt:!0,pc:!0,em:!0,ex:!0,ch:!0,rem:!0,vw:!0,vh:!0,vmin:!0,vmax:!0,"%":!0};function a(e){var t=function(e){if("number"==typeof e)return{value:e,unit:"px"};var t,r=(e.match(/^[0-9.]*/)||"").toString();t=r.includes(".")?parseFloat(r):parseInt(r,10);var i=(e.match(/[^0-9]*$/)||"").toString();return n[i]?{value:t,unit:i}:(console.warn("React Spinners: ".concat(e," is not a valid css value. Defaulting to ").concat(t,"px.")),{value:t,unit:"px"})}(e);return"".concat(t.value).concat(t.unit)}var o=function(){return(o=Object.assign||function(e){for(var t,r=1,i=arguments.length;r<i;r++)for(var n in t=arguments[r])Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n]);return e}).apply(this,arguments)},s=function(e,t){var r={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&0>t.indexOf(i)&&(r[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols)for(var n=0,i=Object.getOwnPropertySymbols(e);n<i.length;n++)0>t.indexOf(i[n])&&Object.prototype.propertyIsEnumerable.call(e,i[n])&&(r[i[n]]=e[i[n]]);return r},l=function(e,t,r){var i="react-spinners-".concat(e,"-").concat(r);if("undefined"==typeof window||!window.document)return i;var n=document.createElement("style");document.head.appendChild(n);var a=n.sheet,o="\n    @keyframes ".concat(i," {\n      ").concat(t,"\n    }\n  ");return a&&a.insertRule(o,0),i}("BeatLoader","50% {transform: scale(0.75);opacity: 0.2} 100% {transform: scale(1);opacity: 1}","beat");let d=function(e){var t=e.loading,r=e.color,n=void 0===r?"#000000":r,d=e.speedMultiplier,c=void 0===d?1:d,p=e.cssOverride,u=e.size,h=void 0===u?15:u,m=e.margin,g=void 0===m?2:m,f=s(e,["loading","color","speedMultiplier","cssOverride","size","margin"]),v=o({display:"inherit"},void 0===p?{}:p),x=function(e){return{display:"inline-block",backgroundColor:n,width:a(h),height:a(h),margin:a(g),borderRadius:"100%",animation:"".concat(l," ").concat(.7/c,"s ").concat(e%2?"0s":"".concat(.35/c,"s")," infinite linear"),animationFillMode:"both"}};return void 0===t||t?i.createElement("span",o({style:v},f),i.createElement("span",{style:x(1)}),i.createElement("span",{style:x(2)}),i.createElement("span",{style:x(3)})):null}},97291:(e,t,r)=>{"use strict";r.d(t,{ZP:()=>s});var i=r(68570);let n=(0,i.createProxy)(String.raw`C:\Users\BOSS\Desktop\git\2024\Baby-n-Stuff-frontend\app\components\shared\Header.tsx`),{__esModule:a,$$typeof:o}=n;n.default;let s=(0,i.createProxy)(String.raw`C:\Users\BOSS\Desktop\git\2024\Baby-n-Stuff-frontend\app\components\shared\Header.tsx#default`)},70458:(e,t,r)=>{"use strict";r.d(t,{Z:()=>c});var i=r(19510);r(71159);var n=r(97291),a=r(68570);let o=(0,a.createProxy)(String.raw`C:\Users\BOSS\Desktop\git\2024\Baby-n-Stuff-frontend\app\components\shared\Footer.tsx`),{__esModule:s,$$typeof:l}=o;o.default;let d=(0,a.createProxy)(String.raw`C:\Users\BOSS\Desktop\git\2024\Baby-n-Stuff-frontend\app\components\shared\Footer.tsx#default`),c=({children:e})=>(0,i.jsxs)(i.Fragment,{children:[i.jsx(n.ZP,{}),e,i.jsx(d,{})]})}};