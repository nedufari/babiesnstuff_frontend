exports.id=8827,exports.ids=[8827],exports.modules={12973:(t,e,r)=>{Promise.resolve().then(r.bind(r,64653)),Promise.resolve().then(r.bind(r,68072))},22763:(t,e,r)=>{"use strict";r.d(e,{Z:()=>h});var o=r(10326),a=r(35049),i=r(6420),s=r(95831),n=r(25609),d=r(87700),l=r(46226);r(17577);var p=r(90434),u=r(13900),c=r(31190);let h=({productImages:t,name:e,price:r,id:h})=>{let[g,{isLoading:m}]=(0,u.od)(),f=async t=>{try{t.preventDefault();let{success:e,message:r,payload:o}=await g({id:h,quantity:1}).unwrap();e?c.Am.success(`${r}`,{position:"top-right",autoClose:5e3,hideProgressBar:!1,closeOnClick:!0,pauseOnHover:!0,draggable:!0,progress:void 0,theme:"light"}):c.Am.error(`${r}`,{position:"top-right",autoClose:5e3,hideProgressBar:!1,closeOnClick:!0,pauseOnHover:!0,draggable:!0,progress:void 0,theme:"light"})}catch(e){let t=e.message||e.data&&e.data.message||"An error occurred";c.Am.error(`${t}`,{position:"top-right",autoClose:5e3,hideProgressBar:!1,closeOnClick:!0,pauseOnHover:!0,draggable:!0,progress:void 0,theme:"light"})}},x=t.length>0?t[0]:"/assets/images/cloth.png";return(0,o.jsxs)(a.Z,{sx:{borderRadius:"6px",backgroundColor:"#FFF",padding:"0.5rem",display:"grid",gridTemplateColumns:"1fr",gridTemplateRows:"4.5fr 0.5fr 0.5fr 1fr",width:"100%"},children:[o.jsx(i.Z,{sx:{"& > a > img":{position:"static !important",objectFit:{xs:"cover !important",md:"cover !important"}},alignSelf:{xs:"stretch",md:"stretch"}},children:o.jsx(p.default,{href:`/products/${h}`,children:o.jsx(l.default,{src:x,alt:"Heading baby Picture",fill:!0,sizes:"100%",style:{objectFit:"cover"}})})}),o.jsx(s.Z,{title:e,subtitle:(0,o.jsxs)("span",{children:["₦ ",r]}),position:"below",sx:{fontFamily:"'__Inter_611e81','__Inter_Fallback_611e81'",color:"#6D6D6D",paddingLeft:{xs:"0.5rem",md:"2rem"},"&  .MuiImageListItemBar-subtitle":{color:"#000000",fontWeight:600,fontSize:"16px"}}}),o.jsx(n.Z,{variant:"poster",fontWeight:"500",fontSize:"16px",lineHeight:"19.36px",color:"#656565",sx:{textDecoration:"line-through",paddingLeft:{xs:"0.5rem",md:"2rem"}},children:1.2*Number(r)}),o.jsx(d.Z,{component:"label",variant:"outlined",tabIndex:-1,sx:{border:"1px solid transparent",borderImage:"linear-gradient(to right, #397F98, #FFA013) 1",backgroundColor:"transparent",borderRadius:"3px",textTransform:"capitalize",width:"90%",alignSelf:"center",justifySelf:"center"},onClick:f,children:o.jsx(n.Z,{fontWeight:"600",fontSize:"16px",textAlign:"center",lineHeight:"32px",sx:{background:"linear-gradient(to right, #397F98 0%, #FFA013 100%)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"},children:"Add to Cart"})})]},h)}},36981:(t,e,r)=>{"use strict";r.d(e,{J3:()=>s,Jy:()=>a,U6:()=>o,jC:()=>i,uQ:()=>n,xq:()=>d});let{usePostProductMutation:o,useGetAllProductsQuery:a,useGetAllProductsNoAuthQuery:i,useGetSingleProductNoAuthQuery:s,useGetAllSearchProductsQuery:n,useDeleteProductMutation:d}=r(63955).g.injectEndpoints({endpoints:t=>({postProduct:t.mutation({query:t=>({url:"/product-mgt/new-product",method:"POST",body:t}),invalidatesTags:[{type:"products",id:"LIST"}]}),getAllProducts:t.query({query:()=>({url:"/product-mgt/fetch-all-products",method:"GET",validateStatus:(t,e)=>200===t.status&&!e.isError}),providesTags:t=>t?[...t.map(({id:t})=>({type:"products",id:t})),{type:"products",id:"LIST"}]:[{type:"products",id:"LIST"}],transformResponse:t=>t.payload.products[0]}),getAllProductsNoAuth:t.query({query:()=>({url:"/browse/fetch-all-products",method:"GET",validateStatus:(t,e)=>200===t.status&&!e.isError}),providesTags:t=>t?[...t.map(({id:t})=>({type:"products",id:t})),{type:"products",id:"LIST"}]:[{type:"products",id:"LIST"}],transformResponse:t=>t.payload.products[0]}),getSingleProductNoAuth:t.query({query:t=>({url:`/browse/fetch-one-product/${t}`,method:"GET",validateStatus:(t,e)=>200===t.status&&!e.isError}),providesTags:(t,e,r)=>[{type:"products",id:r}]}),getAllSearchProducts:t.query({query:t=>({url:`browse/search-product?keyword=${t}`,method:"GET",validateStatus:(t,e)=>200===t.status&&!e.isError}),providesTags:t=>t?[...t.map(({id:t})=>({type:"products",id:t})),{type:"products",id:"LIST"}]:[{type:"products",id:"LIST"}],transformResponse:t=>t.payload.data}),deleteProduct:t.mutation({query:t=>({url:`product-mgt/take-down-product/${t}`,method:"DELETE"}),invalidatesTags:[{type:"products",id:"LIST"}]})}),overrideExisting:!0})},55976:(t,e,r)=>{"use strict";r.d(e,{Z:()=>P});var o=r(91367),a=r(45353),i=r(17577),s=r(41135),n=r(8106),d=r(88634),l=r(19452),p=r(22553),u=r(91703),c=r(2791),h=r(71685),g=r(97898);function m(t){return(0,g.ZP)("MuiSkeleton",t)}(0,h.Z)("MuiSkeleton",["root","text","rectangular","rounded","circular","pulse","wave","withChildren","fitContent","heightAuto"]);var f=r(10326);let x=["animation","className","component","height","style","variant","width"],y=t=>t,b,v,S,w,C=t=>{let{classes:e,variant:r,animation:o,hasChildren:a,width:i,height:s}=t;return(0,d.Z)({root:["root",r,o,a&&"withChildren",a&&!i&&"fitContent",a&&!s&&"heightAuto"]},m,e)},k=(0,n.F4)(b||(b=y`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`)),T=(0,n.F4)(v||(v=y`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`)),F=(0,u.ZP)("span",{name:"MuiSkeleton",slot:"Root",overridesResolver:(t,e)=>{let{ownerState:r}=t;return[e.root,e[r.variant],!1!==r.animation&&e[r.animation],r.hasChildren&&e.withChildren,r.hasChildren&&!r.width&&e.fitContent,r.hasChildren&&!r.height&&e.heightAuto]}})(({theme:t,ownerState:e})=>{let r=(0,l.Wy)(t.shape.borderRadius)||"px",o=(0,l.YL)(t.shape.borderRadius);return(0,a.Z)({display:"block",backgroundColor:t.vars?t.vars.palette.Skeleton.bg:(0,p.Fq)(t.palette.text.primary,"light"===t.palette.mode?.11:.13),height:"1.2em"},"text"===e.variant&&{marginTop:0,marginBottom:0,height:"auto",transformOrigin:"0 55%",transform:"scale(1, 0.60)",borderRadius:`${o}${r}/${Math.round(o/.6*10)/10}${r}`,"&:empty:before":{content:'"\\00a0"'}},"circular"===e.variant&&{borderRadius:"50%"},"rounded"===e.variant&&{borderRadius:(t.vars||t).shape.borderRadius},e.hasChildren&&{"& > *":{visibility:"hidden"}},e.hasChildren&&!e.width&&{maxWidth:"fit-content"},e.hasChildren&&!e.height&&{height:"auto"})},({ownerState:t})=>"pulse"===t.animation&&(0,n.iv)(S||(S=y`
      animation: ${0} 2s ease-in-out 0.5s infinite;
    `),k),({ownerState:t,theme:e})=>"wave"===t.animation&&(0,n.iv)(w||(w=y`
      position: relative;
      overflow: hidden;

      /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
      -webkit-mask-image: -webkit-radial-gradient(white, black);

      &::after {
        animation: ${0} 2s linear 0.5s infinite;
        background: linear-gradient(
          90deg,
          transparent,
          ${0},
          transparent
        );
        content: '';
        position: absolute;
        transform: translateX(-100%); /* Avoid flash during server-side hydration */
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
      }
    `),T,(e.vars||e).palette.action.hover)),P=i.forwardRef(function(t,e){let r=(0,c.i)({props:t,name:"MuiSkeleton"}),{animation:i="pulse",className:n,component:d="span",height:l,style:p,variant:u="text",width:h}=r,g=(0,o.Z)(r,x),m=(0,a.Z)({},r,{animation:i,component:d,variant:u,hasChildren:!!g.children}),y=C(m);return(0,f.jsx)(F,(0,a.Z)({as:d,ref:e,className:(0,s.Z)(y.root,n),ownerState:m},g,{style:(0,a.Z)({width:h,height:l},p)}))})},97291:(t,e,r)=>{"use strict";r.d(e,{ZP:()=>n});var o=r(68570);let a=(0,o.createProxy)(String.raw`C:\Users\BOSS\Desktop\git\2024\Baby-n-Stuff-frontend\app\components\shared\Header.tsx`),{__esModule:i,$$typeof:s}=a;a.default;let n=(0,o.createProxy)(String.raw`C:\Users\BOSS\Desktop\git\2024\Baby-n-Stuff-frontend\app\components\shared\Header.tsx#default`)},70458:(t,e,r)=>{"use strict";r.d(e,{Z:()=>p});var o=r(19510);r(71159);var a=r(97291),i=r(68570);let s=(0,i.createProxy)(String.raw`C:\Users\BOSS\Desktop\git\2024\Baby-n-Stuff-frontend\app\components\shared\Footer.tsx`),{__esModule:n,$$typeof:d}=s;s.default;let l=(0,i.createProxy)(String.raw`C:\Users\BOSS\Desktop\git\2024\Baby-n-Stuff-frontend\app\components\shared\Footer.tsx#default`),p=({children:t})=>(0,o.jsxs)(o.Fragment,{children:[o.jsx(a.ZP,{}),t,o.jsx(l,{})]})}};